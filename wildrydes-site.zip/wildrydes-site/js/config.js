window._config = {
  cognito: {
    userPoolId: "us-east-1_MX1zjZbgi", // e.g. us-east-2_uXboG5pAb
    userPoolClientId: "3jq7qohgj4kf8359ggj1pcvl46", // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
    region: "us-east-1", // e.g. us-east-2
  },
  api: {
    invokeUrl: "https://grspkumd6j.execute-api.us-east-1.amazonaws.com/prod", // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
  },
};
